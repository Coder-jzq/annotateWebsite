
wx.createComponent({
    generic:true,
    props: {},
    render: function(){}
})
